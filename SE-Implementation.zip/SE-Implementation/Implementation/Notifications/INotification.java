package Notifications;
import Budget.*;

public interface INotification {
    public void sendNotification(BudgetManegement budget);
}
