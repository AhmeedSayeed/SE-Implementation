package Validation;
import Users.User;

public interface IValidation {
    public Boolean validate(User user);
}
